package com.blaze.tests;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.blaze.pages.HomePage;
import com.blaze.utilities.BasePage;

public class HomePageTests extends BasePage {
	
	WebDriver driver;
	@BeforeTest
	public void openHomepage() {
		driver = openBrowser("chrome");
	}
	
	@AfterTest
    public void closeBrowser() {
        driver.close();
    }
		
	@Test(priority=1)
	public void verifyHomepage() {
		HomePage homePage = new HomePage();
		Assert.assertTrue(homePage.verifyHomeDisplayed());
	}
	
	@Test(priority=2)
	public void verifyBookingWithValidValues() {
		HomePage homePage = new HomePage();
		homePage.selectDeparture("Boston");
		homePage.selectDestination("Berlin");
		homePage.clickSubmit();
	}
}