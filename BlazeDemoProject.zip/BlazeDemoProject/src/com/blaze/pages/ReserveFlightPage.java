package com.blaze.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.blaze.utilities.BaseBrowser;

public class ReserveFlightPage extends BaseBrowser {
	String pageURL = "https://blazedemo.com/reserve.php";

	@FindBy(xpath = "//div[@class='navbar-inner']/div[@class='container']")
	WebElement navBar;
	
	@FindBy(xpath="//div[@class='container']/h3")
	WebElement headerMsg;
	
	@FindBy(xpath="//table[@class='table']")
	WebElement flightTable;	
	
	
	public ReserveFlightPage () {
		PageFactory.initElements(driver, this);
	}
	
	public boolean isReservePageDisplayed() {
		return driver.getCurrentUrl().equalsIgnoreCase(pageURL) && flightTable.isDisplayed();
	}
	
	public WebElement getFlightByFlightNo(String resFlightNo) {
		WebElement flightFound=null;
		List<WebElement> flightList = flightTable.findElements(By.xpath("//tr"));
		for (WebElement flightRow:flightList) {
			//System.out.println(flightRow.findElement(By.xpath("//td[2]")).getText());
			String flightNo = flightRow.findElement(By.xpath("//td[2]")).getText();
			if(flightNo.equals(resFlightNo)) {
				flightFound= flightRow;
				break;
			}
		}
		return flightFound;
	}
	
	public void getFlightByFlightName(String resFlightName) {		
		List<WebElement> flightList = flightTable.findElements(By.xpath("//tr"));
		System.out.println(flightList);
		for (int i=1; i<=flightList.size();i++) {
			String rowXpath1 = "//table[@class='table']//tr["+i+"]/td[3]";
			System.out.println(driver.findElement(By.xpath(rowXpath1)).getText());
			String flightName = driver.findElement(By.xpath(rowXpath1)).getText();
			if(flightName.equals(resFlightName)) {
				//table[@class='table']//tr[1]/td[1]/input[@type='submit']
				String rowXpath2 = "//table[@class='table']//tr["+i+"]/td[1]/input[@type='submit']";
				driver.findElement(By.xpath(rowXpath2)).click();
				break;
			}
		}
	}
	
	public void selectFlight(WebElement flightRow) {
		//table[@class='table']//tr[1]/td[1]/input[@type='submit']
		flightRow.findElement(By.xpath("/td[1]/input[@type='submit']")).click();
	}
}
