package com.blaze.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.blaze.utilities.BaseBrowser;
import com.blaze.utilities.BasePage;

public class HomePage extends BaseBrowser {
	String pageURL = "https://blazedemo.com/";
	
	@FindBy(xpath = "//div[@class='navbar-inner']/div[@class='container']")
	WebElement navBar;
	
	@FindBy(xpath="//div[@class='container']/h1")
	WebElement headerMsg;
	
	@FindBy(xpath="//div[@class='container']/p[1]")
	WebElement headPara1;
	
	@FindBy(xpath="//div[@class='container']/p[2]")
	WebElement headPara2;
	
	@FindBy(xpath="//div[@class='container']/p[2]/a")
	WebElement headPara2Link;
	
	@FindBy(xpath="//div[@class='container']/h2")
	WebElement headDeparture;
	
	@FindBy(xpath="//form//h2")
	WebElement headDestination;
	
	@FindBy(xpath="//select[@name='fromPort']")
	WebElement fromPort;
	
	@FindBy(xpath="//select[@name='toPort']")
	WebElement toPort;
	
	@FindBy(xpath="//input[@type='submit']")
	WebElement submitBtn;
	
	public HomePage () {
		PageFactory.initElements(driver, this);
	}
	
	public boolean verifyHomeDisplayed() {
		new WebDriverWait(driver, 3000).until(ExpectedConditions.elementToBeClickable(fromPort));
		return driver.getCurrentUrl().equals(pageURL)
				&& driver.getTitle().equals("BlazeDemo")
				&& submitBtn.isDisplayed();		
	}
	
	public void selectDeparture(String fromCity) {
		new WebDriverWait(driver, 3000).until(ExpectedConditions.elementToBeClickable(fromPort));
		fromPort.click();
		//ArrayList<String> destList = new ArrayList<String>();
		//List<WebElement> destEleList = fromPort.findElements(By.xpath("/option"));
		Select deptDropdown = new Select(fromPort);
		deptDropdown.selectByValue(fromCity);		
	}
	
	public void selectDestination(String toCity) {
		new WebDriverWait(driver, 3000).until(ExpectedConditions.elementToBeClickable(toPort));
		toPort.click();
		Select destDropdown = new Select(toPort);
		destDropdown.selectByValue(toCity);		
	}
	
	public void clickSubmit() {
		submitBtn.click();
	}
}