package com.blaze.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.blaze.utilities.BaseBrowser;
import com.blaze.utilities.BasePage;

public class ConfirmationPage extends BaseBrowser {
	String pageURL = "https://blazedemo.com/confirmation.php";
	BasePage basePage;

	@FindBy(xpath = "//div[@class='navbar-inner']/div[@class='container']")
	WebElement navBar;
	
	@FindBy(xpath="//div[@class='container hero-unit']/h1")
	WebElement headerMsg;
	
	@FindBy(xpath="//table[@class='table']")
	WebElement confirmTable;
	
	@FindBy(xpath="//table[@class='table']//tr[2]/td[2]")
	WebElement confirmStatus;
	
	public ConfirmationPage () {
		PageFactory.initElements(driver, this);
	}
	
	public boolean isConfirmPageDisplayed() {
		return driver.getCurrentUrl().equalsIgnoreCase(pageURL) && confirmTable.isDisplayed();
	}
	
	public String getHeaderMessage() {
		return headerMsg.getText();
	}
	
	public String getConfirmStatus() {
		return confirmStatus.getText();
	}
}
