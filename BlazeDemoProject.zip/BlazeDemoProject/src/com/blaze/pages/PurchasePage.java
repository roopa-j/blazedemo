package com.blaze.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.blaze.utilities.BaseBrowser;
import com.blaze.utilities.BasePage;

public class PurchasePage extends BasePage {
	String pageURL = "https://blazedemo.com/purchase.php";
	

	@FindBy(xpath = "//div[@class='navbar-inner']/div[@class='container']")
	WebElement navBar;
	
	@FindBy(xpath="//div[@class='container']/h2")
	WebElement headerMsg;
	
	@FindBy(xpath="//div[@class='container']//p[1]")
	WebElement airline;	
	
	@FindBy(xpath="//div[@class='container']//p[2]")
	WebElement flightNumber;
	
	@FindBy(xpath="//div[@class='container']//p[3]")
	WebElement price;
	
	@FindBy(xpath="//div[@class='container']//p[4]")
	WebElement arbFeesTaxes;
	
	@FindBy(xpath="//div[@class='container']//p[5]/em")
	WebElement totalCost;
	
	@FindBy(id="inputName")
	WebElement custName;
	
	@FindBy(id="address")
	WebElement custAddress;
	
	@FindBy(id="city")
	WebElement custCity;
	
	@FindBy(id="state")
	WebElement custState;
	
	@FindBy(id="zipCode")
	WebElement custZipCode;
	
	@FindBy(id="cardType")
	WebElement custCardType;
	
	@FindBy(id="creditCardNumber")
	WebElement creditCardNumber;
	
	@FindBy(id="creditCardMonth")
	WebElement creditCardMonth;
	
	@FindBy(id="creditCardYear")
	WebElement creditCardYear;
	
	@FindBy(id="nameOnCard")
	WebElement custNameOnCard;
	
	@FindBy(id="rememberMe")
	WebElement rememberMe;
	
	@FindBy(xpath="//input[@type='submit']")
	WebElement submitBtn;
	
	@FindBy(xpath="//form[@method='POST' and @action='https://blazedemo.com/confirmation.php']")
	WebElement purchaseForm;
	
	public PurchasePage () {
		PageFactory.initElements(driver, this);
	}
	
	public boolean isPurchasePageDisplayed() {
		return driver.getCurrentUrl().equalsIgnoreCase(pageURL) && purchaseForm.isDisplayed();
	}
	
	public void fillAndSubmitPurchaseForm(String name, String address, String city, String state, String zipcode, String cardType,
			String cardNum, String cardMonth, String cardYear, String cardName) {
		BasePage basePage = new BasePage();
		basePage.sendText(custName, name);
		basePage.sendText(custAddress, address);
		basePage.sendText(custCity, city);
		basePage.sendText(custState, state);
		basePage.sendText(custZipCode, zipcode);
		basePage.selectFromDropdownByText(custCardType, cardType);
		basePage.sendText(creditCardNumber, cardNum);
		basePage.sendText(creditCardMonth, cardMonth);
		basePage.sendText(creditCardYear, cardYear);
		basePage.sendText(custNameOnCard, cardName);
		basePage.selectCheckbox(rememberMe);
		basePage.clickButton(submitBtn);		
	}
}
