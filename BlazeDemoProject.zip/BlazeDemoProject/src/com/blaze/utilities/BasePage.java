package com.blaze.utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class BasePage extends BaseBrowser {
	public BasePage () {
		PageFactory.initElements(driver, this);
	}
	
	public void sendText(WebElement textbox, String text) {
		textbox.click();
		textbox.clear();
		textbox.sendKeys(text);
	}
	
	public void selectFromDropdownByText(WebElement dropdown, String text) {
		Select select = new Select(dropdown);
		select.selectByVisibleText(text);
	}
	
	public void selectCheckbox(WebElement checkbox) {
		checkbox.click();
	}
	
	public void clickButton(WebElement button) {
		button.click();
	}
	
}
