package com.blaze.utilities;

public class TestData {
	public static String CUST_NAME = "John Smith";
	public static String ADDRESS_1 = "1070 Poplar Avenue";
	public static String CITY_1 = "San Diego";
	public static String STATE_1 = "CA";
	public static String ZIPCODE_1 = "92105";
	public static String CARD_TYPE = "Visa";
	public static String CREDIT_CARD_NO_VISA = "4111111111111111";
	public static String CREDIT_MONTH = "MAY";
	public static String CREDIT_YEAR = "2035";
	
	
}
