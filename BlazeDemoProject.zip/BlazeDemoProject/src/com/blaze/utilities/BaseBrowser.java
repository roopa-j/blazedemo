package com.blaze.utilities;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class BaseBrowser {

    public static WebDriver driver;
    public static String appURL="https://blazedemo.com/";

   public static WebDriver openBrowser(String browserType)
   {
       // If the browser is Firefox, set the path for geckodriver.exe
	   if(browserType.equalsIgnoreCase("firefox"))
	   {
		   System.setProperty("webdriver.gecko.driver","C:\\Users\\rjaganoor\\Documents\\selenium\\jars\\geckodriver.exe");
		   driver = new FirefoxDriver();
	   }

       // If the browser is Chrome, set the path for chromedriver.exe
	   else if(browserType.equalsIgnoreCase("Chrome"))
	   {
           System.setProperty("webdriver.chrome.driver","C:\\Users\\rjaganoor\\Documents\\selenium\\jars\\chromedriver.exe");
           driver = new ChromeDriver();
	   }
	   
           // If the browser is IE, set the path for IEDriverServer.exe
	   else if(browserType.equalsIgnoreCase("IE"))
	   {
           System.setProperty("webdriver.ie.driver","E://Selenium//Selenium_Jars//IEDriverServer.exe");
		   driver = new InternetExplorerDriver();
	   }

	   driver.get(appURL);
	   driver.manage().window().maximize();
	   driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	   return driver;
	}
}